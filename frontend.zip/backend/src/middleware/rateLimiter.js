/**
 * RoomSync Rate Limiting Middleware
 * 
 * In-memory sliding window rate limiter designed for security-critical endpoints
 * such as forgot-password and reset-password.
 * 
 * Provides:
 * - Deterministic protection against credential stuffing and email bombing
 * - Standard RoomSync error envelope (429 status code)
 * - Reset hook for clean testing cycles
 */

const hitMap = new Map();

/**
 * Factory to create rate limiting middleware for sensitive endpoints
 * 
 * @param {object} options
 * @param {number} options.windowMs - Sliding window duration in milliseconds
 * @param {number} options.max - Maximum permitted requests within the window
 * @param {string} options.message - User-facing message when limit is exceeded
 * @param {string} [options.prefix='rl'] - Cache key prefix
 * @returns {import('express').RequestHandler}
 */
export function createRateLimiter({
  windowMs = 15 * 60 * 1000,
  max = 5,
  message = 'Too many requests. Please try again later.',
  prefix = 'rl',
}) {
  return (req, res, next) => {
    // Determine client identifier: combination of prefix, IP, and optional body identifier
    const clientIp =
      req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
      req.socket.remoteAddress ||
      req.ip ||
      'unknown-ip';

    const key = `${prefix}:${clientIp}`;
    const now = Date.now();

    const record = hitMap.get(key) || { count: 0, resetTime: now + windowMs };

    if (now > record.resetTime) {
      record.count = 1;
      record.resetTime = now + windowMs;
    } else {
      record.count += 1;
    }

    hitMap.set(key, record);

    if (record.count > max) {
      const retryAfterSeconds = Math.ceil((record.resetTime - now) / 1000);
      res.setHeader('Retry-After', retryAfterSeconds);

      return res.status(429).json({
        success: false,
        message,
        error: {
          code: 'RATE_LIMIT_EXCEEDED',
          message,
          retryAfter: retryAfterSeconds,
        },
      });
    }

    next();
  };
}

/**
 * Reset all rate limiting tracking records (useful in test teardown)
 */
export function resetRateLimits() {
  hitMap.clear();
}

/** Pre-configured limiter for forgot-password: 5 requests per 15 minutes */
export const forgotPasswordLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: 'Too many password reset requests from this connection. Please try again after 15 minutes.',
  prefix: 'forgot-pwd',
});

/** Pre-configured limiter for reset-password: 10 attempts per 15 minutes */
export const resetPasswordLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: 'Too many password reset verification attempts. Please try again after 15 minutes.',
  prefix: 'reset-pwd',
});
