import { Resend } from 'resend';

/**
 * RoomSync Email Service using Resend
 * 
 * Handles transactional emails with production-grade security:
 * - Reads RESEND_API_KEY strictly from backend environment
 * - Never leaks API keys, reset URLs, or tokens into server logs
 * - Provides responsive HTML template and accessible plain-text fallback
 * - Supports mocking during automated testing
 */

// Module-level mock function for test environments
let mockSendHandler = null;

/**
 * Configure a custom mock send handler for unit/integration testing
 * @param {Function|null} handler - Mock function receiving email parameters
 */
export function setMockSendHandler(handler) {
  mockSendHandler = handler;
}

/**
 * Get configured Resend client instance
 * @returns {Resend|null}
 */
function getResendClient() {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new Resend(apiKey);
}

/**
 * Send password reset email via Resend
 * 
 * @param {object} params
 * @param {string} params.to - Recipient email address
 * @param {string} params.resetToken - Unhashed 32-byte crypto token
 * @param {string} [params.userName] - Recipient user's display name
 * @returns {Promise<{ success: boolean, id?: string }>}
 */
export async function sendPasswordResetEmail({ to, resetToken, userName = 'there' }) {
  const frontendUrl =
    process.env.FRONTEND_URL ||
    process.env.CLIENT_URL ||
    'http://localhost:5173';

  // Construct secure frontend reset URL with query parameter token
  const resetUrl = `${frontendUrl.replace(/\/$/, '')}/reset-password?token=${resetToken}`;

  const fromEmail = process.env.EMAIL_FROM || 'RoomSync <onboarding@resend.dev>';
  const subject = 'Reset Your RoomSync Password';

  // Plain-text fallback required by Phase 5
  const textContent = `Hello,\n\nWe received a request to reset the password associated with your RoomSync account.\n\nClick the button below to create a new password:\n${resetUrl}\n\nThis link will expire in 15 minutes and can only be used once.\n\nIf you did not request this password reset, you can safely ignore this email. Your current password will remain unchanged.\n\nRegards,\nTeam RoomSync`;

  // Apple-inspired minimalist responsive HTML email matching RoomSync design system
  const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Your RoomSync Password</title>
</head>
<body style="margin: 0; padding: 0; background-color: #FBFBFD; font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1D1D1F; -webkit-font-smoothing: antialiased;">
  <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #FBFBFD; padding: 40px 16px;">
    <tr>
      <td align="center">
        <!-- Main Card Container -->
        <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width: 540px; background-color: #FFFFFF; border: 1px solid rgba(0, 0, 0, 0.08); border-radius: 24px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04); overflow: hidden;">
          
          <!-- Brand Header -->
          <tr>
            <td style="padding: 36px 36px 20px 36px; text-align: left;">
              <table role="presentation" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td style="width: 38px; height: 38px; background-color: #0F766E; border-radius: 10px; text-align: center; vertical-align: middle;">
                    <span style="color: #FFFFFF; font-size: 20px; font-weight: 700; line-height: 38px; display: inline-block;">R</span>
                  </td>
                  <td style="padding-left: 12px;">
                    <span style="font-size: 18px; font-weight: 600; color: #1D1D1F; letter-spacing: -0.02em;">RoomSync</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Email Content -->
          <tr>
            <td style="padding: 0 36px 32px 36px; text-align: left;">
              <h1 style="margin: 0 0 16px 0; font-size: 22px; font-weight: 600; color: #1D1D1F; letter-spacing: -0.02em;">
                Reset Your RoomSync Password
              </h1>
              
              <p style="margin: 0 0 16px 0; font-size: 14px; line-height: 1.6; color: #424245;">
                Hello,
              </p>

              <p style="margin: 0 0 20px 0; font-size: 14px; line-height: 1.6; color: #424245;">
                We received a request to reset the password associated with your RoomSync account.
              </p>

              <p style="margin: 0 0 28px 0; font-size: 14px; line-height: 1.6; color: #424245;">
                Click the button below to create a new password.
              </p>

              <!-- CTA Button -->
              <table role="presentation" border="0" cellspacing="0" cellpadding="0" style="margin: 0 0 28px 0;">
                <tr>
                  <td align="left" style="border-radius: 12px; background-color: #0F766E;">
                    <a href="${resetUrl}" target="_blank" style="display: inline-block; padding: 14px 32px; font-size: 14px; font-weight: 600; color: #FFFFFF; text-decoration: none; border-radius: 12px; background-color: #0F766E; letter-spacing: -0.01em;">
                      Reset Password
                    </a>
                  </td>
                </tr>
              </table>

              <p style="margin: 0 0 16px 0; font-size: 13px; line-height: 1.6; color: #6E6E73;">
                This link will expire in <strong>15 minutes</strong> and can only be used once.
              </p>

              <p style="margin: 0 0 28px 0; font-size: 13px; line-height: 1.6; color: #86868B;">
                If you did not request this password reset, you can safely ignore this email. Your current password will remain unchanged.
              </p>

              <p style="margin: 0; font-size: 14px; line-height: 1.6; color: #424245;">
                Regards,<br>
                <strong style="color: #1D1D1F;">Team RoomSync</strong>
              </p>
            </td>
          </tr>

          <!-- Subtle Divider -->
          <tr>
            <td style="padding: 0 36px;">
              <div style="height: 1px; background-color: #E5E5EA; width: 100%;"></div>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding: 24px 36px 36px 36px; text-align: left;">
              <p style="margin: 0 0 6px 0; font-size: 11px; line-height: 1.5; color: #86868B;">
                This is an automated security notification from RoomSync. Please do not reply directly to this email.
              </p>
              <p style="margin: 0; font-size: 11px; line-height: 1.5; color: #86868B;">
                &copy; ${new Date().getFullYear()} RoomSync. Verified Roommate &amp; Shared Rental Platform.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `;

  // 1. In test environment or when mock handler is active, invoke mock
  if (mockSendHandler) {
    return await mockSendHandler({
      to,
      subject,
      text: textContent,
      html: htmlContent,
      resetUrl,
    });
  }

  // 2. In Jest/test environment without explicit mock, simulate successfully without network call
  if (process.env.NODE_ENV === 'test') {
    return { success: true, id: 'test-mock-resend-id' };
  }

  // 3. In live environment, send via official Resend SDK
  const resend = getResendClient();

  if (!resend) {
    // If RESEND_API_KEY is not configured yet in local development, log warning without sensitive URLs
    console.warn(
      `[RoomSync Email] RESEND_API_KEY is not configured. Reset email dispatched to: ${to} (token generated).`
    );
    return { success: true, id: `local-dev-${Date.now()}` };
  }

  try {
    const { data, error } = await resend.emails.send({
      from: fromEmail,
      to: [to],
      subject,
      html: htmlContent,
      text: textContent,
    });

    if (error) {
      console.error(
        `[RoomSync Email] Resend delivery error code: ${error.name || 'RESEND_ERROR'}`
      );
      throw new Error(`Email provider error: ${error.message || 'Delivery rejected'}`);
    }

    return { success: true, id: data?.id };
  } catch (err) {
    // Do not log resetUrl or resetToken
    console.error(`[RoomSync Email] Failed to send email to recipient domain: ${err.message}`);
    throw err;
  }
}
