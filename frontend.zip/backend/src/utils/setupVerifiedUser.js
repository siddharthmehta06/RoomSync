import mongoose from 'mongoose';
import User from '../models/User.js';

async function setupAccounts() {
  await mongoose.connect('mongodb://localhost:27017/roomsync');

  const collegeUser = await User.findOne({ email: 'siddharth.mehta24@spit.ac.in' });
  if (collegeUser) {
    collegeUser.isVerified = true;
    collegeUser.verificationMethod = 'College_ID';
    await collegeUser.save();
    console.log('[Setup] Updated siddharth.mehta24@spit.ac.in to isVerified: true');
  }

  let resendUser = await User.findOne({ email: 'mssiddharth06@gmail.com' });
  if (!resendUser) {
    resendUser = await User.create({
      fullName: 'Siddharth Mehta',
      email: 'mssiddharth06@gmail.com',
      phone: '9876543210',
      password: 'password123',
      role: 'seeker',
      isVerified: true,
      verificationMethod: 'Work_Email',
      city: 'Mumbai',
    });
    console.log('[Setup] Created verified user for mssiddharth06@gmail.com');
  } else {
    resendUser.isVerified = true;
    resendUser.verificationMethod = 'Work_Email';
    await resendUser.save();
    console.log('[Setup] Ensured mssiddharth06@gmail.com isVerified: true');
  }

  await mongoose.disconnect();
}

setupAccounts().catch(console.error);
